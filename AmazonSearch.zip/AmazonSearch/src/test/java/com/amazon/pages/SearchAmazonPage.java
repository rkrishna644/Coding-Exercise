package com.amazon.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SearchAmazonPage {

	WebDriver driver;

	public SearchAmazonPage(WebDriver driver) {

		this.driver = driver;
	}

	@FindBy(id = "twotabsearchtextbox")
	WebElement amazonSearchBoxInput;

	@FindBy(id = "nav-search-submit-button")
	WebElement amazonSearchBtn;

	@FindBy(xpath = "(//span[@class='a-price' and @data-a-size='l']//span[@class='a-price-whole'])[1]")
	WebElement iteamPrice;

	@FindBy(xpath = "//span[@class='a-size-medium a-color-base a-text-normal']")
	WebElement selectIteam;

	/**
	 * * This method indicates the launch the amazon search page
	 * 
	 * @param url
	 */
	public void launchApplication(String applicationURL) {
		driver.get(applicationURL);
	}

	/**
	 * * This method enter the search input
	 * 
	 * @param String
	 */
	public void enterSearchText(String searchInput) {
		amazonSearchBoxInput.sendKeys(searchInput);
		amazonSearchBoxInput.sendKeys(Keys.TAB);
	}

	/**
	 * This method indicates select search
	 */
	public void selectSearch() {
		amazonSearchBtn.click();
	}

	/**
	 * This method indicates get Iteam price
	 */
	public String getIteamPrice() {
		return iteamPrice.getText();
	}

	/**
	 * This method indicates select iteam
	 */
	public void selectIteam() {
		selectIteam.click();
	}

}
