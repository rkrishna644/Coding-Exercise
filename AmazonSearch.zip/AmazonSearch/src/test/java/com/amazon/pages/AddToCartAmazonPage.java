package com.amazon.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddToCartAmazonPage {
	WebDriver driver;
	WebDriverWait wait = null;

	public AddToCartAmazonPage(WebDriver driver) {

		this.driver = driver;
		wait = new WebDriverWait(driver, 30);
	}

	@FindBy(xpath = "//span[contains(@class,'header-price a-text-normal')]")
	List<WebElement> cartPrice;

	@FindBy(id = "add-to-cart-button")
	WebElement addCartBtn;

	@FindBy(xpath = "//div[@id='tmm-grid-swatch-PAPERBACK']//a")
	WebElement paperBack;
	/**
	 * This method indicates get the price
	 */
	public String getCartPrice() {
		System.out.println("size--->" + cartPrice.size());
		if (cartPrice.size() == 1) {
			return getValidtePrice(cartPrice.get(0).getText());
		} else {
			return getValidtePrice(cartPrice.get(1).getText());
		}

	}
	/**
	 * This method indicates price formating
	 */
	public static String getValidtePrice(String price) {
		price = price.replace("$", "");
		String costVal[] = price.split("\\.");
		if (costVal.length > 0) {
			return costVal[0];
		} else {
			return "";
		}
	}
	/**
	 * This method indicates select add cart button
	 */
	public void selectAddCartButton() {
		addCartBtn.click();
	}
	/**
	 * This method indicates is add cart button is displayed
	 */
	public boolean isVeriyAddToCardButton() {
		boolean isFound = false;
		try {
			isFound = addCartBtn.isDisplayed();
		} catch (Exception e) {
			paperBack.click();
		}
		return isFound;
	}
	/**
	 * This method indicates select search
	 */
	public void slectAddToCartButton() {
		addCartBtn.click();
	}
	/**
	 * This method select paper back
	 */
	public void selectPaperBack() {
		paperBack.click();
	}
}
