package com.amazon.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProceedToCheckOutAmazonPage {
	WebDriver driver;
	
	@FindBy(xpath = "(//span[@class='a-color-price hlb-price a-inline-block a-text-bold'])[1]")
	WebElement checkOutPrice;
	
	@FindBy(xpath = "(//a[contains(text(),'Proceed to checkout')])[1]")
	WebElement proceedToCheckOutBtn;
	
	public ProceedToCheckOutAmazonPage(WebDriver driver) {

		this.driver = driver;

	}

	/**
	 * This method indicates get checkout price value
	 * @return WebElement
	 */
	public String getcheckOutPrice() {
		return getValidtePrice(checkOutPrice.getText());
	}

	/**
	 * This method indicates selecting
	 * proceed to checkout button
	 */
	public void selectProceedTocheckOutBtn() {
		proceedToCheckOutBtn.click();
	}
	public static String getValidtePrice(String price) {
		price=price.replace("$", "");
		String costVal[]=price.split("\\.");
		if(costVal.length>0){
			return costVal[0];
		}else {
			return "";
		}
	}
}