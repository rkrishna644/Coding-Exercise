package com.amazon.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.amazon.pages.AddToCartAmazonPage;
import com.amazon.pages.ProceedToCheckOutAmazonPage;
import com.amazon.pages.SearchAmazonPage;

public class AmazonSearchTest {

	WebDriver driver=null;
	String iteamPrice="";
	String addToCartPrice="";
	
	
	@BeforeClass
	public void getDriver() {
		System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"\\src\\test\\resources\\driver\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
}
	/**
	 * This method performs the launch the amazon search page
	 */
	@Test(priority = 1)
	public void testAmazonSearchPage() {
		SearchAmazonPage searchAmazonPage = PageFactory.initElements(driver, SearchAmazonPage.class);
		searchAmazonPage.launchApplication("https://www.amazon.com/");
		searchAmazonPage.enterSearchText("qa testing for beginners");		
		searchAmazonPage.selectSearch();	
		iteamPrice=searchAmazonPage.getIteamPrice();
		searchAmazonPage.selectIteam();
		
	}
	
	/**
	 * This method validating the iteam price with add to cart price
	 */
	@Test(dependsOnMethods = "testAmazonSearchPage")
	public void testVerifyAddCartPrice() {
		AddToCartAmazonPage addToCartAmazonPage = PageFactory.initElements(driver, AddToCartAmazonPage.class);
		addToCartAmazonPage.isVeriyAddToCardButton();
		/*
		 * if(!addToCartAmazonPage.isVeriyAddToCardButton()) {
		 * addToCartAmazonPage.selectPaperBack(); }
		 * 
		 */
		addToCartPrice=addToCartAmazonPage.getCartPrice();
		Assert.assertEquals(iteamPrice,addToCartPrice);
		addToCartAmazonPage.selectAddCartButton();
	}
	/**
	 * This method validating the add to cart price with checkout price
	 */
	@Test(dependsOnMethods = "testVerifyAddCartPrice")
	public void testVerifyCheckOutPrice() {
		ProceedToCheckOutAmazonPage proceedToCheckOutAmazonPage = PageFactory.initElements(driver, ProceedToCheckOutAmazonPage.class);
		String checkOutPrice=proceedToCheckOutAmazonPage.getcheckOutPrice();		
		Assert.assertEquals(checkOutPrice,addToCartPrice);
		proceedToCheckOutAmazonPage.selectProceedTocheckOutBtn();
	}

	@AfterClass
	public void closeApplication() {
		driver.close();
	}
}
