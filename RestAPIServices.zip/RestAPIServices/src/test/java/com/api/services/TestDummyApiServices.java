package com.api.services;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.api.constants.ServiceConstants;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
public class TestDummyApiServices {
	
	RestUtilities restUtilities=RestUtilities.getInstanceService();
	/*
	 *  GET services or all employees
	 */
	@Test(priority = 1)
	public void testGetAllEmployeeServiceCalls() {		
		Response response = restUtilities.getRequest(ServiceConstants.BASE_URI + "/employees");		
		Assert.assertEquals(restUtilities.getReponseCode(response),ServiceConstants.SUCESS_STATUS_CODE);
	}

	/*
	 * 
	 * DELETE services for particular employee and validating the response message
	 */
	@Test(dependsOnMethods = "testGetAllEmployeeServiceCalls", alwaysRun = true)
	public void testDeleteEmployeeById() {
		RestUtilities restUtilities=RestUtilities.getInstanceService();
		Response response = restUtilities.deleteRequest(ServiceConstants.BASE_URI + "/delete","2");			
		Assert.assertEquals(ServiceConstants.SUCESS_STATUS_CODE, restUtilities.getReponseCode(response));		
		JsonPath jsonPathValidator = restUtilities.getJsonObject(response);		
		Assert.assertEquals(jsonPathValidator.get("status").toString(),ServiceConstants.SUCESS);
		Assert.assertEquals( jsonPathValidator.get("message"),ServiceConstants.DELETE_SERVICE_REPONSE_MSG);
	}
	
	/*
	 * 
	 * DELETE services for particular employee and validating the response message
	 */
	@Test(dependsOnMethods = "testGetAllEmployeeServiceCalls", alwaysRun = true)
	public void testGetEmployeeReponseValidations() {
		RestUtilities services=RestUtilities.getInstanceService();
		Response response = services.getRequest(ServiceConstants.BASE_URI + "/employee/2");		
		Assert.assertEquals(ServiceConstants.SUCESS_STATUS_CODE, services.getReponseCode(response));		
		JsonPath jsonPathValidator = services.getJsonObject(response);
		Assert.assertEquals(jsonPathValidator.get("status").toString(),ServiceConstants.SUCESS);
		Assert.assertEquals(jsonPathValidator.get("data.id").toString(),"2");
		Assert.assertEquals( jsonPathValidator.get("data.employee_name").toString(),"Garrett Winters");
		Assert.assertEquals(jsonPathValidator.get("data.employee_salary").toString(),"170750");
		Assert.assertEquals(jsonPathValidator.get("data.employee_age").toString(),"63");
		Assert.assertEquals(jsonPathValidator.get("message").toString(),ServiceConstants.GET_SERVICE_REPONSE_MSG);

	}
}
