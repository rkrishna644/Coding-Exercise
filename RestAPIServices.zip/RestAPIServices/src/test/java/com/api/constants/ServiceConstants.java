package com.api.constants;

public class ServiceConstants {
	public static final String BASE_URI="http://dummy.restapiexample.com/api/v1";
	public static final int SUCESS_STATUS_CODE=200;
	public static final String SUCESS="success";
	public static final String DELETE_SERVICE_REPONSE_MSG="successfully! deleted Records";
	public static final String GET_SERVICE_REPONSE_MSG="Successfully! Record has been fetched.";
	
}
